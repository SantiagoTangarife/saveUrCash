package co.edu.udea.analisis.saveUr

import java.time.LocalDate
import java.util.*

class Elemento(val Titulo:String,val Valor:Float, val Imagen:Int, val Fecha:String) {
}