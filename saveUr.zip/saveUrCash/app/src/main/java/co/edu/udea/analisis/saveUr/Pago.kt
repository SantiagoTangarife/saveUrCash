package co.edu.udea.analisis.saveUr

class Pago(val Amigo:String) {
}