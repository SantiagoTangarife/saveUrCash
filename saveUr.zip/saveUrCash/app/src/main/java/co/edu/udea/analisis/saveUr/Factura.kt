package co.edu.udea.analisis.saveUr

class Factura(val Titulo:String,val Fecha:String,val Costo:String, val Cuota:String,val Imagen:Int) {
}