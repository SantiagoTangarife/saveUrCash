package co.edu.udea.analisis.saveUr

import android.graphics.Color
import android.widget.ProgressBar

class Grave: Estado() {
    override fun color(tinte: ProgressBar){
        tinte.progressDrawable.setColorFilter(Color.YELLOW,android.graphics.PorterDuff.Mode.SRC_IN)
    }
}