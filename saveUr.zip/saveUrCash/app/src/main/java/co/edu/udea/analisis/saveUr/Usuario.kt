package co.edu.udea.analisis.saveUr

class Usuario {
    val nombre:String = ""
    val correo:String=""
    val direccion:String=""


    fun getUser(): String {
            return nombre}

}